export const Logo = ({ className = "w-16 h-16" }: { className?: string }) => {
  return (
    <svg className={className} viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Golden ornate circle */}
      <circle cx="100" cy="100" r="95" fill="url(#goldGradient)" opacity="0.1"/>
      
      {/* Moroccan pattern star */}
      <path d="M100 20 L110 70 L160 70 L120 100 L140 150 L100 120 L60 150 L80 100 L40 70 L90 70 Z" 
            fill="url(#goldGradient)"/>
      
      {/* Inner decorative circle */}
      <circle cx="100" cy="100" r="70" stroke="url(#goldGradient)" strokeWidth="2" fill="none"/>
      <circle cx="100" cy="100" r="60" stroke="url(#goldGradient)" strokeWidth="1" fill="none" opacity="0.5"/>
      
      {/* Decorative dots */}
      <circle cx="100" cy="40" r="3" fill="url(#goldGradient)"/>
      <circle cx="100" cy="160" r="3" fill="url(#goldGradient)"/>
      <circle cx="40" cy="100" r="3" fill="url(#goldGradient)"/>
      <circle cx="160" cy="100" r="3" fill="url(#goldGradient)"/>
      
      {/* Center letter "S" for Soltana */}
      <text 
        x="100" 
        y="115" 
        fontSize="60" 
        fontWeight="bold" 
        fontFamily="serif"
        fill="url(#goldGradient)" 
        textAnchor="middle"
      >
        S
      </text>
      
      <defs>
        <linearGradient id="goldGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#f59e0b"/>
          <stop offset="50%" stopColor="#d97706"/>
          <stop offset="100%" stopColor="#f59e0b"/>
        </linearGradient>
      </defs>
    </svg>
  );
};

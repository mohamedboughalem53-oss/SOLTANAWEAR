import { useEffect, useState } from 'react';
import { Logo } from './Logo';

interface SplashScreenProps {
  onFinish: () => void;
}

export const SplashScreen = ({ onFinish }: SplashScreenProps) => {
  const [fadeOut, setFadeOut] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setFadeOut(true);
      setTimeout(onFinish, 800);
    }, 2500);

    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <div 
      className={`fixed inset-0 z-[100] flex items-center justify-center transition-opacity duration-700 ${
        fadeOut ? 'opacity-0' : 'opacity-100'
      }`}
      style={{
        background: 'linear-gradient(135deg, #1f2937 0%, #111827 50%, #1f2937 100%)'
      }}
    >
      {/* Animated background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-full h-full" 
             style={{
               backgroundImage: `radial-gradient(circle at 20% 50%, rgba(217, 119, 6, 0.3) 0%, transparent 50%),
                                 radial-gradient(circle at 80% 80%, rgba(245, 158, 11, 0.3) 0%, transparent 50%),
                                 radial-gradient(circle at 40% 20%, rgba(217, 119, 6, 0.2) 0%, transparent 50%)`,
               animation: 'pulse 4s ease-in-out infinite'
             }}
        />
      </div>

      <div className="relative z-10 text-center">
        {/* Logo Animation */}
        <div className="mb-8 animate-fadeIn flex justify-center">
          <div className="relative">
            <Logo className="w-32 h-32 animate-pulse" />
            <div className="absolute inset-0 animate-spin-slow">
              <div className="w-32 h-32 rounded-full border-2 border-transparent border-t-amber-500 opacity-50"></div>
            </div>
          </div>
        </div>

        {/* Brand Name */}
        <h1 className="text-5xl md:text-6xl font-serif font-bold mb-4 animate-fadeIn" 
            style={{
              background: 'linear-gradient(135deg, #f59e0b, #d97706, #f59e0b)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
              animationDelay: '0.3s'
            }}>
          سلطانة وير
        </h1>
        
        <p className="text-2xl md:text-3xl text-white/90 mb-2 font-light animate-fadeIn" 
           style={{ animationDelay: '0.5s' }}>
          Soltana Wear
        </p>

        <div className="flex items-center justify-center gap-4 mb-8 animate-fadeIn" 
             style={{ animationDelay: '0.7s' }}>
          <div className="h-px w-16 bg-gradient-to-r from-transparent to-amber-500"></div>
          <p className="text-amber-400 text-sm tracking-[0.3em]">NOUADHIBOU</p>
          <div className="h-px w-16 bg-gradient-to-l from-transparent to-amber-500"></div>
        </div>

        {/* Subtitle */}
        <p className="text-white/70 text-lg animate-fadeIn" 
           style={{ animationDelay: '0.9s' }}>
          بيجامات مغربية فاخرة
        </p>
        <p className="text-white/60 animate-fadeIn" 
           style={{ animationDelay: '1s' }}>
          Pyjamas Marocains de Luxe
        </p>

        {/* Loading dots */}
        <div className="flex justify-center gap-2 mt-8 animate-fadeIn" 
             style={{ animationDelay: '1.2s' }}>
          <div className="w-2 h-2 rounded-full bg-amber-500 animate-bounce" style={{ animationDelay: '0s' }}></div>
          <div className="w-2 h-2 rounded-full bg-amber-500 animate-bounce" style={{ animationDelay: '0.2s' }}></div>
          <div className="w-2 h-2 rounded-full bg-amber-500 animate-bounce" style={{ animationDelay: '0.4s' }}></div>
        </div>
      </div>
    </div>
  );
};

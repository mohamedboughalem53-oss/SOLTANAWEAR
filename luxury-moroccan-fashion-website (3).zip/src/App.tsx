import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ShoppingCart, Menu, X, Heart, Search, Star, Truck, Shield, 
  Award, ChevronRight, Clock, Gift, Phone, Mail, MapPin, Send,
  Check, Package, CreditCard, Users, Zap
} from 'lucide-react';
import { FaWhatsapp, FaTiktok, FaInstagram } from 'react-icons/fa';

// Types
interface Product {
  id: number;
  name: string;
  nameAr: string;
  price: number;
  originalPrice?: number;
  category: string;
  image: string;
  rating: number;
  reviews: number;
  badge?: string;
  inStock: boolean;
  description: string;
}

interface CartItem extends Product {
  quantity: number;
}

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<number[]>([]);
  const [scrolled, setScrolled] = useState(false);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('all');

  const whatsappNumber = '+22249904310';

  // Enhanced Products Data
  const products: Product[] = [
    {
      id: 1,
      name: 'Royal Silk Pajama',
      nameAr: 'بيجامة حريرية ملكية',
      price: 18000,
      originalPrice: 24000,
      category: 'pajamas',
      image: '/images/pyjama1.jpg',
      rating: 5,
      reviews: 124,
      badge: 'Best Seller',
      inStock: true,
      description: 'Luxurious silk pajama set with elegant gold embroidery'
    },
    {
      id: 2,
      name: 'Premium Cotton Night Set',
      nameAr: 'طقم نوم قطني فاخر',
      price: 15000,
      originalPrice: 19000,
      category: 'pajamas',
      image: '/images/pyjama2.jpg',
      rating: 5,
      reviews: 98,
      badge: 'New',
      inStock: true,
      description: '100% premium cotton for ultimate comfort'
    },
    {
      id: 3,
      name: 'Designer Black Abaya',
      nameAr: 'عباية سوداء مصممة',
      price: 22000,
      originalPrice: 28000,
      category: 'abayas',
      image: '/images/collection3.jpg',
      rating: 5,
      reviews: 156,
      badge: 'Premium',
      inStock: true,
      description: 'Elegant designer abaya with golden details'
    },
    {
      id: 4,
      name: 'Traditional Moroccan Jellaba',
      nameAr: 'جلابة مغربية تقليدية',
      price: 16500,
      originalPrice: 21000,
      category: 'jellabas',
      image: '/images/collection2.jpg',
      rating: 4.5,
      reviews: 87,
      inStock: true,
      description: 'Authentic Moroccan craftsmanship'
    },
    {
      id: 5,
      name: 'Velvet Luxury Pajama',
      nameAr: 'بيجامة مخملية فاخرة',
      price: 19500,
      category: 'pajamas',
      image: '/images/pyjama3.jpg',
      rating: 5,
      reviews: 142,
      badge: 'Limited',
      inStock: true,
      description: 'Soft velvet fabric for winter nights'
    },
    {
      id: 6,
      name: 'Elegant Beige Abaya',
      nameAr: 'عباية بيج أنيقة',
      price: 25000,
      originalPrice: 32000,
      category: 'abayas',
      image: '/images/collection1.jpg',
      rating: 5,
      reviews: 203,
      badge: 'Trending',
      inStock: true,
      description: 'Modern design with traditional elegance'
    },
    {
      id: 7,
      name: 'Luxury Embroidered Jellaba',
      nameAr: 'جلابة مطرزة فاخرة',
      price: 20000,
      originalPrice: 26000,
      category: 'jellabas',
      image: '/images/bestseller1.jpg',
      rating: 5,
      reviews: 134,
      badge: 'Premium',
      inStock: true,
      description: 'Hand-embroidered with golden threads'
    },
    {
      id: 8,
      name: 'Summer Silk Pajama',
      nameAr: 'بيجامة حريرية صيفية',
      price: 17000,
      originalPrice: 22000,
      category: 'pajamas',
      image: '/images/bestseller2.jpg',
      rating: 5,
      reviews: 167,
      badge: 'New',
      inStock: true,
      description: 'Light and breathable for hot nights'
    }
  ];

  const filteredProducts = selectedCategory === 'all' 
    ? products 
    : products.filter(p => p.category === selectedCategory);

  // Scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Loading animation
  useEffect(() => {
    setTimeout(() => setLoading(false), 2500);
  }, []);

  // Cart functions
  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (id: number) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const updateQuantity = (id: number, change: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = Math.max(1, item.quantity + change);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const toggleWishlist = (id: number) => {
    setWishlist(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const savings = cart.reduce((sum, item) => 
    sum + ((item.originalPrice || item.price) - item.price) * item.quantity, 0
  );

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black flex items-center justify-center z-50">
        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            className="w-24 h-24 border-4 border-amber-500 border-t-transparent rounded-full mx-auto mb-6"
          />
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-white font-serif text-3xl mb-2"
          >
            Soltana Wear
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="text-amber-400 text-sm tracking-widest"
          >
            LUXURY MOROCCAN FASHION
          </motion.p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Top Announcement Bar */}
      <div className="bg-black text-white text-center py-2 text-sm">
        <div className="flex items-center justify-center gap-2">
          <Gift size={16} className="text-amber-400" />
          <span>توصيل مجاني للطلبات أكثر من 30,000 أوقية | Livraison Gratuite + 30,000 MRU | Code: SOLTANA20</span>
        </div>
      </div>

      {/* Navbar */}
      <motion.nav
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className={`sticky top-0 w-full z-50 transition-all duration-300 ${
          scrolled
            ? 'bg-white/95 backdrop-blur-md shadow-lg'
            : 'bg-white/90 backdrop-blur-sm'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            {/* Logo */}
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="cursor-pointer flex items-center gap-3"
            >
              <div className="w-10 h-10 bg-gradient-to-br from-amber-500 to-amber-600 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-xl">S</span>
              </div>
              <div>
                <h1 className="font-serif text-2xl font-bold text-black">
                  Soltana Wear
                </h1>
                <p className="text-xs text-gray-500 tracking-wide">LUXURY FASHION</p>
              </div>
            </motion.div>

            {/* Desktop Menu */}
            <div className="hidden lg:flex items-center gap-8">
              <a href="#home" className="text-black hover:text-amber-600 transition font-medium">
                الرئيسية
              </a>
              <a href="#pajamas" className="text-black hover:text-amber-600 transition font-medium">
                بيجامات
              </a>
              <a href="#abayas" className="text-black hover:text-amber-600 transition font-medium">
                عبايات
              </a>
              <a href="#jellabas" className="text-black hover:text-amber-600 transition font-medium">
                جلابيب
              </a>
              <a href="#new-arrivals" className="text-black hover:text-amber-600 transition font-medium">
                جديد
              </a>
            </div>

            {/* Icons */}
            <div className="flex items-center gap-4">
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                className="hidden md:block text-black hover:text-amber-600 transition"
              >
                <Search size={20} />
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                className="relative text-black hover:text-amber-600 transition"
              >
                <Heart size={20} />
                {wishlist.length > 0 && (
                  <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center font-bold">
                    {wishlist.length}
                  </span>
                )}
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setIsCartOpen(true)}
                className="relative text-black hover:text-amber-600 transition"
              >
                <ShoppingCart size={20} />
                {cartCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-amber-600 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center font-bold">
                    {cartCount}
                  </span>
                )}
              </motion.button>

              <motion.a
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                href={`https://wa.me/${whatsappNumber}`}
                target="_blank"
                rel="noopener noreferrer"
                className="hidden md:flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-full transition font-bold shadow-lg text-base"
              >
                <FaWhatsapp size={22} />
                <span>اطلب الآن</span>
              </motion.a>

              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="lg:hidden text-black"
              >
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="lg:hidden bg-white border-t shadow-xl"
            >
              <div className="px-4 py-6 space-y-4">
                <a href="#home" className="block py-3 text-lg hover:text-amber-600 transition font-medium">
                  الرئيسية
                </a>
                <a href="#pajamas" className="block py-3 text-lg hover:text-amber-600 transition font-medium">
                  بيجامات
                </a>
                <a href="#abayas" className="block py-3 text-lg hover:text-amber-600 transition font-medium">
                  عبايات
                </a>
                <a href="#jellabas" className="block py-3 text-lg hover:text-amber-600 transition font-medium">
                  جلابيب
                </a>
                <a href="#new-arrivals" className="block py-3 text-lg hover:text-amber-600 transition font-medium">
                  جديد
                </a>
                <a
                  href={`https://wa.me/${whatsappNumber}`}
                  className="flex items-center justify-center gap-3 bg-green-600 text-white px-8 py-5 rounded-full font-bold mt-4 text-lg"
                >
                  <FaWhatsapp size={26} />
                  اطلب عبر واتساب
                </a>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.nav>

      {/* Hero Section */}
      <section id="home" className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/40 z-10"></div>
        <motion.img
          initial={{ scale: 1.1 }}
          animate={{ scale: 1 }}
          transition={{ duration: 1.5 }}
          src="/images/hero.jpg"
          alt="Luxury Fashion"
          className="absolute inset-0 w-full h-full object-cover"
        />
        
        <div className="relative z-20 text-center px-4 max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.3, type: 'spring', stiffness: 200 }}
              className="inline-block mb-6 bg-amber-600/20 backdrop-blur-md px-8 py-3 rounded-full border border-amber-500/50"
            >
              <span className="text-amber-300 text-sm font-bold tracking-widest">✨ NEW WINTER COLLECTION 2024</span>
            </motion.div>

            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="text-5xl md:text-7xl lg:text-8xl font-serif font-bold text-white mb-6 leading-tight"
            >
              الفخامة تلتقي
              <br />
              <span className="bg-gradient-to-r from-amber-400 via-amber-300 to-amber-400 bg-clip-text text-transparent">
                بالأصالة
              </span>
            </motion.h1>
            
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.7 }}
              className="text-xl md:text-2xl text-white/90 mb-4 font-light"
            >
              Luxe Marocain pour Femmes Modernes
            </motion.p>

            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.9 }}
              className="text-white/70 mb-10 max-w-2xl mx-auto text-lg leading-relaxed"
            >
              اكتشفي مجموعتنا الحصرية من البيجامات الفاخرة، العبايات الأنيقة والجلابيب التقليدية
            </motion.p>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.1 }}
              className="flex flex-col sm:flex-row gap-4 justify-center items-center"
            >
              <motion.a
                whileHover={{ scale: 1.05, y: -2 }}
                whileTap={{ scale: 0.95 }}
                href="#collection"
                className="bg-white text-black px-10 py-5 rounded-full font-bold hover:bg-amber-50 transition shadow-2xl text-lg"
              >
                تصفح المجموعة
              </motion.a>
              
              <motion.a
                whileHover={{ scale: 1.05, y: -2 }}
                whileTap={{ scale: 0.95 }}
                href={`https://wa.me/${whatsappNumber}?text=السلام عليكم، أريد الاستفسار عن المجموعة الفاخرة`}
                target="_blank"
                className="bg-green-600 text-white px-12 py-5 rounded-full font-bold hover:bg-green-700 transition shadow-2xl flex items-center gap-3 text-xl"
              >
                <FaWhatsapp size={28} />
                اطلب عبر واتساب
              </motion.a>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.3 }}
              className="flex flex-wrap justify-center gap-8 mt-12 text-white/70 text-sm"
            >
              <div className="flex items-center gap-2">
                <Truck size={18} className="text-amber-400" />
                <span>توصيل مجاني</span>
              </div>
              <div className="flex items-center gap-2">
                <Shield size={18} className="text-amber-400" />
                <span>دفع آمن</span>
              </div>
              <div className="flex items-center gap-2">
                <Award size={18} className="text-amber-400" />
                <span>جودة فاخرة</span>
              </div>
              <div className="flex items-center gap-2">
                <Package size={18} className="text-amber-400" />
                <span>توصيل نفس اليوم</span>
              </div>
            </motion.div>
          </motion.div>
        </div>

        {/* Scroll Indicator */}
        <motion.div
          animate={{ y: [0, 12, 0] }}
          transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
          className="absolute bottom-10 left-1/2 transform -translate-x-1/2 z-20"
        >
          <div className="w-7 h-11 border-2 border-white/40 rounded-full flex justify-center p-2">
            <motion.div 
              animate={{ y: [0, 8, 0] }}
              transition={{ repeat: Infinity, duration: 1.5 }}
              className="w-1.5 h-3 bg-white/60 rounded-full"
            />
          </div>
        </motion.div>
      </section>

      {/* Promo Banner */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="bg-gradient-to-r from-amber-600 via-amber-500 to-amber-600 py-5 relative overflow-hidden"
      >
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRjMC0yLjIxIDEuNzktNCA0LTRzNCAxLjc5IDQgNC0xLjc5IDQtNCA0LTQtMS43OS00LTR6bTAgMTBjMC0yLjIxIDEuNzktNCA0LTRzNCAxLjc5IDQgNC0xLjc5IDQtNCA0LTQtMS43OS00LTR6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-20"></div>
        <div className="max-w-7xl mx-auto px-4 flex flex-wrap justify-center items-center gap-4 text-white text-center relative z-10">
          <motion.div
            animate={{ rotate: [0, 10, 0] }}
            transition={{ repeat: Infinity, duration: 2 }}
          >
            <Gift size={24} />
          </motion.div>
          <p className="font-bold text-lg">
            🎉 عرض محدود: خصم 20% + هدية مجانية | Offre Limitée: -20% + Cadeau Gratuit
          </p>
          <div className="flex items-center gap-2 bg-white/20 px-4 py-2 rounded-full backdrop-blur-sm">
            <Clock size={18} />
            <span className="font-mono font-bold">Code: SOLTANA20</span>
          </div>
        </div>
      </motion.div>

      {/* Trust Badges */}
      <section className="py-16 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { 
                icon: <Truck className="text-amber-600" />, 
                title: 'توصيل مجاني', 
                desc: 'Livraison Gratuite',
                color: 'from-amber-50 to-orange-50'
              },
              { 
                icon: <Shield className="text-blue-600" />, 
                title: 'دفع آمن', 
                desc: 'Paiement Sécurisé',
                color: 'from-blue-50 to-cyan-50'
              },
              { 
                icon: <Award className="text-purple-600" />, 
                title: 'جودة فاخرة', 
                desc: 'Qualité Premium',
                color: 'from-purple-50 to-pink-50'
              },
              { 
                icon: <Zap className="text-green-600" />, 
                title: 'خدمة 24/7', 
                desc: 'Support WhatsApp',
                color: 'from-green-50 to-emerald-50'
              }
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -5 }}
                className={`text-center p-6 rounded-2xl bg-gradient-to-br ${item.color} shadow-md hover:shadow-xl transition-all duration-300`}
              >
                <div className="w-16 h-16 mx-auto mb-4 bg-white rounded-2xl flex items-center justify-center shadow-lg">
                  {item.icon}
                </div>
                <h3 className="font-bold mb-1 text-gray-900">{item.title}</h3>
                <p className="text-sm text-gray-600">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Category Filter */}
      <section id="collection" className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-wrap justify-center gap-3 mb-12">
            {[
              { id: 'all', label: 'جميع المنتجات', icon: <Package size={18} /> },
              { id: 'pajamas', label: 'بيجامات', icon: '🌙' },
              { id: 'abayas', label: 'عبايات', icon: '👗' },
              { id: 'jellabas', label: 'جلابيب', icon: '✨' }
            ].map((cat) => (
              <motion.button
                key={cat.id}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center gap-2 px-6 py-3 rounded-full font-semibold transition-all ${
                  selectedCategory === cat.id
                    ? 'bg-black text-white shadow-lg'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {typeof cat.icon === 'string' ? <span>{cat.icon}</span> : cat.icon}
                {cat.label}
              </motion.button>
            ))}
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section className="pb-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-4 text-black">
              مجموعة حصرية
            </h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">
              Collection Exclusive de Luxe - قطع مختارة بعناية من أجود الخامات
            </p>
            <div className="w-24 h-1 bg-gradient-to-r from-transparent via-amber-500 to-transparent mx-auto mt-6"></div>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredProducts.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                viewport={{ once: true }}
                whileHover={{ y: -8 }}
                className="group relative bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500 border border-gray-100"
              >
                {/* Product Image */}
                <div className="relative overflow-hidden aspect-[3/4] bg-gray-100">
                  <motion.img
                    whileHover={{ scale: 1.1 }}
                    transition={{ duration: 0.6 }}
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                  
                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

                  {/* Badges */}
                  {product.badge && (
                    <motion.div 
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="absolute top-4 left-4 bg-amber-600 text-white px-4 py-1.5 rounded-full text-xs font-bold shadow-xl"
                    >
                      {product.badge}
                    </motion.div>
                  )}

                  {product.originalPrice && (
                    <div className="absolute top-4 right-4 bg-red-600 text-white px-3 py-1.5 rounded-full text-xs font-bold shadow-xl">
                      Save {Math.round((1 - product.price / product.originalPrice) * 100)}%
                    </div>
                  )}

                  {/* Wishlist Button */}
                  <motion.button
                    whileHover={{ scale: 1.15 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => toggleWishlist(product.id)}
                    className={`absolute top-16 right-4 w-11 h-11 rounded-full flex items-center justify-center backdrop-blur-md border-2 transition-all ${
                      wishlist.includes(product.id)
                        ? 'bg-red-500 text-white border-red-500'
                        : 'bg-white/80 text-gray-700 border-white/50 hover:bg-white'
                    }`}
                  >
                    <Heart size={18} fill={wishlist.includes(product.id) ? 'currentColor' : 'none'} />
                  </motion.button>

                  {/* Quick Actions - Show on Hover */}
                  <div className="absolute bottom-4 left-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-4 group-hover:translate-y-0">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => addToCart(product)}
                      className="flex-1 bg-white text-black py-3 rounded-xl font-bold hover:bg-amber-50 transition flex items-center justify-center gap-2 shadow-xl"
                    >
                      <ShoppingCart size={18} />
                      أضف
                    </motion.button>
                    <motion.a
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      href={`https://wa.me/${whatsappNumber}?text=مرحباً، أريد الاستفسار عن ${product.nameAr}`}
                      target="_blank"
                      className="bg-green-600 text-white p-3 rounded-xl hover:bg-green-700 transition shadow-xl"
                    >
                      <FaWhatsapp size={22} />
                    </motion.a>
                  </div>
                </div>

                {/* Product Info */}
                <div className="p-5">
                  {/* Rating */}
                  <div className="flex items-center gap-1 mb-2">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        size={14}
                        className={i < Math.floor(product.rating) ? 'text-amber-500 fill-amber-500' : 'text-gray-300'}
                      />
                    ))}
                    <span className="text-xs text-gray-500 ml-2">({product.reviews})</span>
                  </div>

                  <h3 className="font-bold text-lg mb-1 text-gray-900 line-clamp-1">{product.name}</h3>
                  <p className="text-sm text-gray-500 mb-3 line-clamp-1">{product.nameAr}</p>

                  {/* Price */}
                  <div className="flex items-center justify-between">
                    <div>
                      {product.originalPrice && (
                        <span className="text-sm text-gray-400 line-through mr-2">
                          {product.originalPrice.toLocaleString()} MRU
                        </span>
                      )}
                      <div className="flex items-baseline gap-1">
                        <span className="text-2xl font-bold text-amber-600">
                          {product.price.toLocaleString()}
                        </span>
                        <span className="text-sm text-gray-500">MRU</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 text-green-600 text-xs font-semibold">
                      <Check size={14} />
                      <span>متوفر</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* View All Button */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mt-16"
          >
            <motion.button
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
              className="bg-black text-white px-12 py-4 rounded-full font-bold hover:bg-gray-900 transition inline-flex items-center gap-3 shadow-xl text-lg"
            >
              عرض جميع المنتجات
              <ChevronRight size={22} />
            </motion.button>
          </motion.div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-20 bg-gradient-to-br from-black via-gray-900 to-black text-white relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute top-0 left-0 w-96 h-96 bg-amber-500 rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-amber-500 rounded-full blur-3xl"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-4">
              لماذا سلطانة وير؟
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              Pourquoi Choisir Soltana Wear? - ملتزمون بتقديم الجودة الاستثنائية
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: <Users size={32} />,
                title: '1000+ عميلة سعيدة',
                desc: 'Plus de 1000 Clientes Satisfaites',
                color: 'from-blue-500 to-cyan-500'
              },
              {
                icon: <Award size={32} />,
                title: 'خامات فاخرة',
                desc: 'Matériaux Premium de Luxe',
                color: 'from-purple-500 to-pink-500'
              },
              {
                icon: <Shield size={32} />,
                title: 'جودة مضمونة',
                desc: 'Qualité Garantie 100%',
                color: 'from-amber-500 to-orange-500'
              },
              {
                icon: <Truck size={32} />,
                title: 'توصيل سريع',
                desc: 'Livraison Rapide - Nouadhibou',
                color: 'from-green-500 to-emerald-500'
              },
              {
                icon: <CreditCard size={32} />,
                title: 'دفع آمن',
                desc: 'Paiement Sécurisé',
                color: 'from-red-500 to-rose-500'
              },
              {
                icon: <FaWhatsapp size={32} />,
                title: 'طلب سهل',
                desc: 'Commande Facile WhatsApp',
                color: 'from-green-600 to-green-700'
              }
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -5 }}
                className="bg-white/5 backdrop-blur-sm p-8 rounded-3xl border border-white/10 hover:border-amber-500/50 transition-all duration-300"
              >
                <div className={`w-16 h-16 bg-gradient-to-br ${item.color} rounded-2xl flex items-center justify-center mb-6 shadow-lg`}>
                  <div className="text-white">
                    {item.icon}
                  </div>
                </div>
                <h3 className="text-xl font-bold mb-3 text-white">{item.title}</h3>
                <p className="text-gray-400 leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Customer Reviews */}
      <section className="py-20 bg-gradient-to-b from-white to-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-4 text-black">
              آراء عملائنا
            </h2>
            <p className="text-gray-600 text-lg">
              Avis de nos Clientes - ماذا يقول عملاؤنا عنا
            </p>
            <div className="flex justify-center items-center gap-2 mt-4">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="text-amber-500 fill-amber-500" size={20} />
              ))}
              <span className="text-gray-700 font-bold ml-2">4.9/5 من 500+ تقييم</span>
            </div>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: 'Fatima Hassan',
                location: 'Nouadhibou',
                text: 'أجمل بيجامات في نواذيبو! الجودة ممتازة والتوصيل سريع جداً. أنصح الجميع بالشراء من سلطانة وير 💕',
                rating: 5,
                verified: true
              },
              {
                name: 'Aisha Mohammed',
                location: 'Nouakchott',
                text: 'Absolutely love the quality! The abayas are stunning and comfortable. Customer service is exceptional. Will definitely order again!',
                rating: 5,
                verified: true
              },
              {
                name: 'Khadija Omar',
                location: 'Nouadhibou',
                text: 'Service excellent et produits authentiques. La livraison était rapide et l\'emballage très soigné. Je recommande fortement! ⭐',
                rating: 5,
                verified: true
              }
            ].map((review, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.15 }}
                viewport={{ once: true }}
                whileHover={{ y: -5 }}
                className="bg-white p-8 rounded-3xl shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-100"
              >
                <div className="flex gap-1 mb-4">
                  {[...Array(review.rating)].map((_, j) => (
                    <Star key={j} size={18} className="text-amber-500 fill-amber-500" />
                  ))}
                </div>
                <p className="text-gray-700 mb-6 leading-relaxed text-lg">{review.text}</p>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-bold text-black">{review.name}</p>
                    <p className="text-sm text-gray-500">{review.location}</p>
                  </div>
                  {review.verified && (
                    <div className="flex items-center gap-1 text-green-600 text-xs font-semibold bg-green-50 px-3 py-1 rounded-full">
                      <Check size={14} />
                      موثق
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-amber-600 via-amber-500 to-amber-600 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRjMC0yLjIxIDEuNzktNCA0LTRzNCAxLjc5IDQgNC0xLjc5IDQtNCA0LTQtMS43OS00LTR6bTAgMTBjMC0yLjIxIDEuNzktNCA0LTRzNCAxLjc5IDQgNC0xLjc5IDQtNCA0LTQtMS43OS00LTR6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-20"></div>
        
        <div className="max-w-4xl mx-auto px-4 text-center text-white relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <motion.div
              animate={{ scale: [1, 1.05, 1] }}
              transition={{ repeat: Infinity, duration: 2 }}
              className="inline-block mb-6"
            >
              <Gift size={48} />
            </motion.div>
            
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-6">
              جاهزة للتسوق الفاخر؟
            </h2>
            <p className="text-xl mb-4 text-white/90">
              احصلي على خصم 20% + هدية مجانية | -20% + Cadeau Gratuit
            </p>
            <p className="text-white/80 mb-10 text-lg">
              تسوقي الآن عبر واتساب مع توصيل في نفس اليوم بنواذيبو
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.a
                whileHover={{ scale: 1.05, y: -2 }}
                whileTap={{ scale: 0.95 }}
                href={`https://wa.me/${whatsappNumber}?text=مرحباً! أريد استخدام كود الخصم SOLTANA20`}
                target="_blank"
                className="inline-flex items-center gap-3 bg-white text-amber-600 px-12 py-6 rounded-full font-bold text-xl shadow-2xl hover:bg-gray-50 transition"
              >
                <FaWhatsapp size={32} />
                تسوق عبر واتساب
              </motion.a>
              
              <motion.a
                whileHover={{ scale: 1.05, y: -2 }}
                whileTap={{ scale: 0.95 }}
                href="#collection"
                className="inline-flex items-center gap-3 bg-black text-white px-12 py-6 rounded-full font-bold text-xl shadow-2xl hover:bg-gray-900 transition"
              >
                تصفح المجموعة
                <ChevronRight size={22} />
              </motion.a>
            </div>

            <p className="mt-8 text-white/70 text-sm">
              ⏰ عرض محدود • Offre limitée • كود الخصم: <span className="font-mono font-bold bg-white/20 px-3 py-1 rounded">SOLTANA20</span>
            </p>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
            {/* Brand */}
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-amber-600 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-2xl">S</span>
                </div>
                <div>
                  <h3 className="font-serif text-2xl font-bold">Soltana Wear</h3>
                  <p className="text-xs text-gray-400">LUXURY FASHION</p>
                </div>
              </div>
              <p className="text-gray-400 mb-6 leading-relaxed">
                Premium Moroccan fashion bringing elegance and tradition to modern women in Nouadhibou.
              </p>
              <div className="flex gap-4">
                <motion.a 
                  whileHover={{ scale: 1.1, y: -2 }}
                  href="https://instagram.com/soltanawear" 
                  target="_blank" 
                  className="w-10 h-10 bg-gradient-to-br from-pink-500 to-rose-500 rounded-full flex items-center justify-center hover:shadow-lg transition"
                >
                  <FaInstagram size={20} />
                </motion.a>
                <motion.a 
                  whileHover={{ scale: 1.1, y: -2 }}
                  href="https://tiktok.com/@soltanawear" 
                  target="_blank" 
                  className="w-10 h-10 bg-black border-2 border-white rounded-full flex items-center justify-center hover:shadow-lg transition"
                >
                  <FaTiktok size={18} />
                </motion.a>
                <motion.a 
                  whileHover={{ scale: 1.1, y: -2 }}
                  href={`https://wa.me/${whatsappNumber}`} 
                  target="_blank" 
                  className="w-10 h-10 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center hover:shadow-lg transition"
                >
                  <FaWhatsapp size={20} />
                </motion.a>
              </div>
            </div>

            {/* Shop */}
            <div>
              <h4 className="font-bold text-lg mb-6">Shop</h4>
              <ul className="space-y-3 text-gray-400">
                <li><a href="#pajamas" className="hover:text-amber-400 transition">Pajamas</a></li>
                <li><a href="#abayas" className="hover:text-amber-400 transition">Abayas</a></li>
                <li><a href="#jellabas" className="hover:text-amber-400 transition">Jellabas</a></li>
                <li><a href="#new-arrivals" className="hover:text-amber-400 transition">New Arrivals</a></li>
                <li><a href="#best-sellers" className="hover:text-amber-400 transition">Best Sellers</a></li>
              </ul>
            </div>

            {/* Customer Care */}
            <div>
              <h4 className="font-bold text-lg mb-6">Customer Care</h4>
              <ul className="space-y-3 text-gray-400">
                <li><a href="#" className="hover:text-amber-400 transition">Delivery Information</a></li>
                <li><a href="#" className="hover:text-amber-400 transition">Returns & Exchange</a></li>
                <li><a href="#" className="hover:text-amber-400 transition">Size Guide</a></li>
                <li><a href="#" className="hover:text-amber-400 transition">FAQs</a></li>
                <li><a href="#" className="hover:text-amber-400 transition">Contact Us</a></li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h4 className="font-bold text-lg mb-6">Get in Touch</h4>
              <ul className="space-y-4 text-gray-400">
                <li className="flex items-start gap-3">
                  <MapPin size={20} className="text-amber-500 flex-shrink-0 mt-1" />
                  <span>3ème Robinet, Nouadhibou, Mauritania</span>
                </li>
                <li className="flex items-center gap-3">
                  <Phone size={20} className="text-amber-500 flex-shrink-0" />
                  <a href={`tel:${whatsappNumber}`} className="hover:text-amber-400 transition">
                    {whatsappNumber}
                  </a>
                </li>
                <li className="flex items-center gap-3">
                  <Mail size={20} className="text-amber-500 flex-shrink-0" />
                  <a href="mailto:contact@soltanawear.mr" className="hover:text-amber-400 transition">
                    contact@soltanawear.mr
                  </a>
                </li>
              </ul>

              {/* Newsletter */}
              <div className="mt-6">
                <h5 className="font-semibold mb-3 text-white">Newsletter</h5>
                <div className="flex gap-2">
                  <input
                    type="email"
                    placeholder="Your email"
                    className="flex-1 px-4 py-2 rounded-full bg-white/10 border border-white/20 focus:outline-none focus:border-amber-500 text-white placeholder-gray-500"
                  />
                  <motion.button 
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="bg-amber-600 p-2 rounded-full hover:bg-amber-700 transition"
                  >
                    <Send size={20} />
                  </motion.button>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-white/10 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-gray-400 text-sm">
              <p>&copy; 2024 Soltana Wear. All rights reserved. Made with ❤️ in Mauritania</p>
              <div className="flex gap-6">
                <a href="#" className="hover:text-amber-400 transition">Privacy Policy</a>
                <a href="#" className="hover:text-amber-400 transition">Terms of Service</a>
                <a href="#" className="hover:text-amber-400 transition">Cookies</a>
              </div>
            </div>
          </div>
        </div>
      </footer>

      {/* Floating WhatsApp - Bigger */}
      <motion.a
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 1 }}
        whileHover={{ scale: 1.15, rotate: 5 }}
        whileTap={{ scale: 0.9 }}
        href={`https://wa.me/${whatsappNumber}`}
        target="_blank"
        className="fixed bottom-8 right-8 bg-green-600 text-white p-6 rounded-full shadow-2xl hover:bg-green-700 transition z-50 group"
        style={{ 
          animation: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
          boxShadow: '0 0 0 0 rgba(22, 163, 74, 0.7)'
        }}
      >
        <FaWhatsapp size={42} />
        <span className="absolute -top-3 -left-3 bg-red-500 text-white text-sm px-3 py-1.5 rounded-full font-bold animate-bounce">
          اطلب
        </span>
      </motion.a>

      {/* Cart Sidebar */}
      <AnimatePresence>
        {isCartOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
            />
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              className="fixed right-0 top-0 h-full w-full md:w-[450px] bg-white shadow-2xl z-50 overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex justify-between items-center mb-8 pb-4 border-b">
                  <div>
                    <h2 className="text-2xl font-bold">سلة التسوق</h2>
                    <p className="text-sm text-gray-500">{cartCount} منتج</p>
                  </div>
                  <button 
                    onClick={() => setIsCartOpen(false)} 
                    className="hover:text-amber-600 transition p-2 hover:bg-gray-100 rounded-full"
                  >
                    <X size={24} />
                  </button>
                </div>

                {cart.length === 0 ? (
                  <div className="text-center py-16">
                    <div className="w-24 h-24 mx-auto mb-6 bg-gray-100 rounded-full flex items-center justify-center">
                      <ShoppingCart size={40} className="text-gray-300" />
                    </div>
                    <h3 className="text-xl font-semibold mb-2">سلتك فارغة</h3>
                    <p className="text-gray-500 mb-6">ابدئي بإضافة منتجات فاخرة!</p>
                    <button
                      onClick={() => setIsCartOpen(false)}
                      className="bg-black text-white px-8 py-3 rounded-full hover:bg-gray-900 transition"
                    >
                      متابعة التسوق
                    </button>
                  </div>
                ) : (
                  <>
                    <div className="space-y-4 mb-6">
                      {cart.map(item => (
                        <motion.div 
                          key={item.id}
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="flex gap-4 border-b pb-4"
                        >
                          <img 
                            src={item.image} 
                            alt={item.name} 
                            className="w-24 h-24 object-cover rounded-xl" 
                          />
                          <div className="flex-1">
                            <h3 className="font-bold text-sm mb-1">{item.name}</h3>
                            <p className="text-xs text-gray-500 mb-2">{item.nameAr}</p>
                            <p className="text-amber-600 font-bold text-lg">
                              {item.price.toLocaleString()} MRU
                            </p>
                            
                            <div className="flex items-center gap-3 mt-2">
                              <div className="flex items-center gap-2 bg-gray-100 rounded-full">
                                <button
                                  onClick={() => updateQuantity(item.id, -1)}
                                  className="w-8 h-8 rounded-full hover:bg-gray-200 transition flex items-center justify-center"
                                >
                                  -
                                </button>
                                <span className="font-semibold w-8 text-center">{item.quantity}</span>
                                <button
                                  onClick={() => updateQuantity(item.id, 1)}
                                  className="w-8 h-8 rounded-full hover:bg-gray-200 transition flex items-center justify-center"
                                >
                                  +
                                </button>
                              </div>
                              
                              <button
                                onClick={() => removeFromCart(item.id)}
                                className="text-red-500 hover:text-red-600 text-xs"
                              >
                                حذف
                              </button>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>

                    <div className="border-t pt-6 space-y-3 mb-6">
                      <div className="flex justify-between text-gray-600">
                        <span>المجموع الفرعي:</span>
                        <span className="font-semibold">{cartTotal.toLocaleString()} أوقية</span>
                      </div>
                      {savings > 0 && (
                        <div className="flex justify-between text-green-600">
                          <span>التوفير:</span>
                          <span className="font-bold">-{savings.toLocaleString()} أوقية</span>
                        </div>
                      )}
                      <div className="flex justify-between text-sm text-gray-500">
                        <span>التوصيل:</span>
                        <span className="font-semibold text-green-600">مجاني</span>
                      </div>
                      <div className="flex justify-between text-xl font-bold pt-3 border-t">
                        <span>الإجمالي:</span>
                        <span className="text-amber-600">{cartTotal.toLocaleString()} أوقية</span>
                      </div>
                    </div>

                    <motion.a
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      href={`https://wa.me/${whatsappNumber}?text=مرحباً! أريد طلب:\n${cart.map(item => `\n- ${item.nameAr} (${item.quantity}×) = ${(item.price * item.quantity).toLocaleString()} أوقية`).join('')}\n\nالإجمالي: ${cartTotal.toLocaleString()} أوقية`}
                      target="_blank"
                      className="flex items-center justify-center gap-3 w-full bg-green-600 text-white py-5 rounded-full font-bold hover:bg-green-700 transition shadow-xl text-xl"
                    >
                      <FaWhatsapp size={28} />
                      اطلب عبر واتساب
                    </motion.a>
                    
                    <p className="text-center text-xs text-gray-500 mt-4">
                      🎁 هدية مجانية مع طلبك • استخدمي كود: SOLTANA20
                    </p>
                  </>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Custom Pulse Animation */}
      <style>{`
        @keyframes pulse {
          0%, 100% {
            box-shadow: 0 0 0 0 rgba(22, 163, 74, 0.7);
          }
          50% {
            box-shadow: 0 0 0 20px rgba(22, 163, 74, 0);
          }
        }
      `}</style>
    </div>
  );
}

export default App;
